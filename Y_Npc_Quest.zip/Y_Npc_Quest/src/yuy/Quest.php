<?php

namespace yuy;

use pocketmine\Player;

use pocketmine\event\Listener;
use pocketmine\plugin\PluginBase;

use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\network\mcpe\protocol\ModalFormRequestPacket;
use pocketmine\network\mcpe\protocol\ModalFormResponsePacket;

use pocketmine\command\Command;
use pocketmine\command\CommandSender;

use pocketmine\item\Item;
use pocketmine\utils\Config;

use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityDeathEvent;

use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\nbt\tag\DoubleTag;
use pocketmine\nbt\tag\ListTag;
use pocketmine\nbt\tag\FloatTag;

use pocketmine\entity\Entity;
use pocketmine\utils\UUID;

use yuy\quest\YQuestEntity;

class Quest extends PluginBase implements Listener{
    
    public $p = "§l§a[ §fQuest §a] §r§f";
    
    public static $instance;

  public static function getInstance(){

    return self::$instance;
  }
  public function onLoad(){
    
    self::$instance = $this;
  }

  /* function broadcastMessage($msg){
       
       $this->getServer()->broadcastMessage($msg);
       
   }*/

    function onEnable(){
        
      
    Entity::registerEntity(YQuestEntity::class, true);
        
    $this->getServer()->getPluginManager()->registerEvents($this, $this);
    
    $this->data = new Config ($this->getDataFolder() . 'Quest.yml', Config::YAML);
    $this->db = $this->data->getAll();
    
    $this->dat = new Config ($this->getDataFolder() . 'clear.yml', Config::YAML);
    $this->pl = $this->dat->getAll();
    
    
}

function onDisable() {
  
    $this->data->setAll($this->db); 
    $this->data->save();
      
    $this->dat->setAll($this->pl); 
    $this->dat->save();
    
}
    
    
    function EntityId($id){
        
        if($id == 12){
            return "돼지";
        }
        if($id == 54){
            return "셜커";
        }
        if($id == 53){
            return "엔더_드레곤";
        }
        if($id == 52){
            return "위더";
        }
        if($id == 51){
            return "NPC";
        }
        if($id == 50){
            return "엘더_가디언";
        }
        if($id == 49){
            return "가디언";
        }
        if($id == 48){
            return "위더_스켈레톤";
        }
        if($id == 47){
            return "허스크";
        }
        if($id == 46){
            return "스트레이";
        }
        if($id == 45){
            return "마녀";
        }
        if($id == 44){
            return "좀비_주민";
        }
        if($id == 43){
            return "블레이즈";
        }
        if($id == 42){
            return "마그마_큐브";
        }
        if($id == 41){
            return "가스트";
        }
        if($id == 40){
            return "동굴_거미";
        }
        if($id == 39){
            return "좀벌레";
        }
        if($id == 38){
            return "엔더맨";
        }
        if($id == 37){
            return "슬라임";
        }
        if($id == 36){
            return "좀비_피그맨";
        }
        if($id == 35){
            return "거미";
        }
        if($id == 34){
            return "스켈레톤";
        }
        if($id == 33){
            return "크리퍼";
        }
        if($id == 31){
            return "돌고래";
        }
        if($id == 30){
            return "앵무새";
        }
        if($id == 29){
            return "라마";
        }
        if($id == 28){
            return "북극곰";
        }
        if($id == 27){
            return "좀비_말";
        }
        if($id == 26){
            return "스켈레톤_말";
        }
        if($id == 25){
            return "노새";
        }
        if($id == 24){
            return "나귀";
        }
        if($id == 23){
            return "말";
        }
        if($id == 22){
            return "오셀롯";
        }
        if($id == 21){
            return "눈사람";
        }
        if($id == 20){
            return "철골램";
        }
        if($id == 19){
            return "박쥐";
        }
        if($id == 18){
            return "토끼";
        }
        if($id == 17){
            return "오징어";
        }
        if($id == 16){
            return "버섯소";
        }
        if($id == 15){
            return "주민";
        }
        if($id == 14){
            return "늑대";
        }
        if($id == 13){
            return "양";
        }
        if($id == 10){
            return "닭";
        }
        if($id == 11){
            return "소";
        }
        if($id == 32){
            return "좀비";
        }
        
        
    }

    function onDeath(EntityDeathEvent $event)
    {
        $player = $event->getEntity();
        $cause = $player->getLastDamageCause();
        if ($cause instanceof EntityDamageByEntityEvent) {
            $damager = $cause->getDamager();
            
            if ($damager instanceof Player) {
                $nn = $damager->getName();
                if(isset($this->pl['Monster'][$nn])){
        $monster = $this->pl['Monster'][$nn];
        $id = $player::NETWORK_ID;
        
        if($id == $monster['id']){
            
            $this->pl['Monster'][$nn]['count']++;
            
            $damager->sendMessage($this->p.self::EntityId($monster['id'])." 사냥 ".$monster['count']."/".$this->pl['Monster'][$nn]['cou']);
            
            if($monster['cou']-1 == $monster['count']){
                $damager->getInventory()->addItem(Item::jsonDeserialize($monster['reward']));
                $damager->sendMessage($this->p."{$monster['name']} 퀘스트를 클리어 했습니다");
                if(isset($this->pl[$nn][$monster['uuid']])){
                $this->pl[$nn][$monster['uuid']]++;
                } else {
                    $this->pl[$nn][$monster['uuid']] = 1;
                }
            
                unset($this->pl['Monster'][$nn]);
            
            }
            
            
        }
                    
                    
                }

        
        }
    }
 }
 
    function onDamage(EntityDamageEvent $event) {
        $entity = $event->getEntity();

        if ($entity instanceof YQuestEntity) {
            $event->setCancelled();
            
            if ($event instanceof EntityDamageByEntityEvent) {
    
    $damager = $event->getDamager();
    
    if ($damager instanceof Player){
        
        $dn = $damager->getName();
        $nn = $dn;
        
        $a = $entity->getUUID();
        $b = $entity->getMessage();
        
if (isset($this->mode[$dn])) {
    
 unset($this->mode[$dn]);
 unset($this->db['Quest'][$a]);
 
 
            $entity->kill();
            
$damager->sendMessage($this->p . "퀘스트 엔티티를 제거 했습니다");
                return true;
                    }
                    
             if(isset($this->Monster['Quest'][$nn])){
                $cre = $this->Monster['Quest'][$nn];
        if(isset($this->db['Quest'][$a])){
            
            $cou = count($this->db['Quest'][$a]);
    $this->db['Quest'][$a][$cou] = [
        'Qtype' => $cre['Qtype'],
        'reward' => $cre['reward'],
        
        'id' => $cre['Id'],
        'count' => $cre['count'],
        'name' => $cre['name']
        
                ];
                
        
            $damager->sendMessage($this->p.'생성 했습니다');
              unset($this->Monster['Quest'][$dn]);
        return true;
            
        } else {
            
            $this->db['Quest'][$a][0] = [
        'Qtype' => $cre['Qtype'],
        'reward' => $cre['reward'],
    
        'id' => $cre['Id'],
        'count' => $cre['count'],
        'name' => $cre['name']
        
                ]; 
        
        $damager->sendMessage($this->p.'생성 했습니다');
          unset($this->Monster['Quest'][$dn]);
        return true;
            }
        
        }
        if(isset($this->Item['Quest'][$nn])){
                $cre = $this->Item['Quest'][$nn];
        if(isset($this->db['Quest'][$a])){
            $it = $damager->getInventory()->getItemInHand();
               $it->setCount($cre['count']);
               $it = $it->jsonSerialize();
            $cou = count($this->db['Quest'][$a]);
    $this->db['Quest'][$a][$cou] = [
        'Qtype' => $cre['Qtype'],
        'reward' => $cre['reward'],
        'item' => $it,
        'count' => $cre['count'],
        'name' => $cre['name']
        
                ];
                
        
            $damager->sendMessage($this->p.'생성 했습니다');
              unset($this->Item['Quest'][$dn]);
        return true;
            
        } else {
               $it = $damager->getInventory()->getItemInHand();
               $it->setCount($cre['count']);
               $it = $it->jsonSerialize();
            $this->db['Quest'][$a][0] = [
        'Qtype' => $cre['Qtype'],
        'reward' => $cre['reward'],
        'item' => $it,
        'name' => $cre['name']
        
                ]; 
        
        $damager->sendMessage($this->p.'생성 했습니다');
          unset($this->Item['Quest'][$dn]);
        return true;
            }
        
        }
    if(isset($this->pl['Monster'][$dn])){
            self::MonsterUi($damager);
            return;
        }
        if(isset($this->pl['Item'][$dn])){
        if(isset($this->pl[$nn][$a])){
            $it = Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$dn]['uuid']][$this->pl[$nn][$this->pl['Item'][$dn]['uuid']]]['item']);
            $itemCount = 0;
            for($i=0; $i<35; $i++){
               $item = $damager->getInventory()->getItem($i);
               if($item->getId() == $it->getId() && $item->getDamage() == $it->getDamage() && $item->getName() == $it->getName()){
                  $itemCount += $item->getCount();
               }
            }
            if($itemCount >= $it->getCount()){
           self::ClearItemUi($damager,$itemCount);
                return;
            } else {
            self::ItemUi($damager,$itemCount);
            return;
            }
            
        } else {
            $it = Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$dn]['uuid']][0]['item']);
            $itemCount = 0;
            for($i=0; $i<35; $i++){
               $item = $damager->getInventory()->getItem($i);
               if($item->getId() == $it->getId() && $item->getDamage() == $it->getDamage() && $item->getName() == $it->getName()){
                  $itemCount += $item->getCount();
               }
            }
            if($itemCount >= $it->getCount()){
           self::ClearItemUi($damager,$itemCount);
                return;
            } else {
            self::ItemUi($damager,$itemCount);
            return;
            }
        }
        }
      
        if(isset($this->db['Quest'][$a])){
            
            if(isset($this->pl[$dn][$a])){
                if(isset($this->db['Quest'][$a][$this->pl[$dn][$a]])){
            self::QuestNpc($damager,$this->pl[$dn][$a],$a);
            return;
                }
            } else {
                
                self::QuestNpc($damager,0,$a);
                return;
            }
            
            
            
            
        }
             
                    if(!isset($this->db['Quest'][$a]) or isset($this->pl[$dn][$a])){
        $damager->sendMessage($b);
    }

                }
            }
        }
    }
    
    function onCommand(CommandSender $sender, Command $command, string $label, array $args) : bool{

    if ($command->getName() === "퀘스트") {
        switch ($args[0] ?? 'X') {
    default:
        
$sender->sendMessage($this->p . "/퀘스트 생성 | 퀘스트를 생성합니다");

$sender->sendMessage($this->p . "/퀘스트 엔피시 | 퀘스트 엔피시를 관리합니다");

    break;
         case '생성':
             
        self::QuestCreate($sender);
 
    break;
    case '제거':
             
        $this->mode[$sender->getName()] = 'on';
        $sender->sendMessage($this->p."해당 엔피시를 터치 해주세요");
 
    break;
       case 'Npc':
       case 'npc':
       case '엔피시':
           
           if(!isset($args[1])){
               
               $sender->sendMessage($this->p . "/퀘스트 엔피시 [생성]");
               $sender->sendMessage($this->p . "/퀘스트 엔피시 [제거]");
               
               break;
               
           }
           if($args[1] == "생성"){
               
        self::QuestNpcCreate($sender);
               
           }
           if($args[1] == "제거"){
               
        self::QuestNpcDelete($sender);
               
           }
           
    break;
        }
}
return true;
}
function MonsterUi(Player $player){
         
    
      $quest = $this->pl['Monster'][$player->getName()];
      
         $item = Item::jsonDeserialize($quest['reward']);
         $mn = self::EntityId($quest['id']);
      $a = "몬스터 잡기\n\n{$mn} 몬스터를 {$quest['cou']}마리 잡기\n\n보상: {$item->getName()} {$item->getCount()} 개\n진행도 {$quest['count']}/{$quest['cou']}";
      
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "포기",
      ],
      [
      "text" => "확인",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17340;
      $pack->formData = $encode;
      $player->dataPacket($pack);
      
     }
     function ItemUi(Player $player,$cou){
         
    
    
      $quest = $this->pl['Item'][$player->getName()];
      $nn = $player->getName();
      if(isset($this->pl[$nn][$this->pl['Item'][$nn]['uuid']])){
         $item = Item::jsonDeserialize($quest['reward']);
         $it = Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$nn]['uuid']][$this->pl[$nn][$this->pl['Item'][$nn]['uuid']]]['item']);

      $a = "아이템 모으기\n{$it->getName()} {$it->getCount()} 개 모으기\n\n보상: {$item->getName()} {$item->getCount()} 개\n\n진행도 {$cou}/{$it->getCount()}";
      
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "포기",
      ],
      [
      "text" => "확인",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17341;
      $pack->formData = $encode;
      $player->dataPacket($pack);
      } else {
          $item = Item::jsonDeserialize($quest['reward']);
         $it = Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$nn]['uuid']][0]['item']);

      $a = "아이템 모으기\n{$it->getName()} {$it->getCount()} 개 모으기\n\n보상: {$item->getName()} {$item->getCount()} 개\n\n진행도 {$cou}/{$it->getCount()}";
      
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "포기",
      ],
      [
      "text" => "확인",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17341;
      $pack->formData = $encode;
      $player->dataPacket($pack);
      }
     }
     function ClearItemUi(Player $player,$cou){
         
    
      $quest = $this->pl['Item'][$player->getName()];
      
         $item = Item::jsonDeserialize($quest['reward']);
         $nn = $player->getName();
         if(isset($this->pl[$nn][$this->pl['Item'][$nn]['uuid']])){
         $it = Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$nn]['uuid']][$this->pl[$nn][$this->pl['Item'][$nn]['uuid']]]['item']);

      $a = "아이템 모으기\n{$it->getName()} {$it->getCount()} 개 모으기\n\n보상: {$item->getName()} {$item->getCount()} 개\n\n진행도 {$cou}/{$it->getCount()}";
      
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "클리어",
      ],
      [
      "text" => "확인",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17342;
      $pack->formData = $encode;
      $player->dataPacket($pack);
         } else {
             $it = Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$nn]['uuid']][0]['item']);

      $a = "아이템 모으기\n{$it->getName()} {$it->getCount()} 개 모으기\n\n보상: {$item->getName()} {$item->getCount()} 개\n\n진행도 {$cou}/{$it->getCount()}";
      
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "클리어",
      ],
      [
      "text" => "확인",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17342;
      $pack->formData = $encode;
      $player->dataPacket($pack);
         }
     }
     function QuestNpc(Player $player,$cou,$npc){
         
    
      $quest = $this->db['Quest'][$npc][$cou];
      
      if($quest['Qtype'] == 0){
         $item = Item::jsonDeserialize($quest['reward']);
         $id = self::EntityId($quest['id']);
      $a = "몬스터 잡기\n\n{$id} 몬스터를 {$quest['count']}마리 잡기\n\n보상: {$item->getName()} {$item->getCount()} 개";
      
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "수락",
      ],
      [
      "text" => "거절",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17338;
      $pack->formData = $encode;
      $player->dataPacket($pack);
      $this->mm[$player->getName()] = ['id'=>$quest['id'],'cou'=>$quest['count'],'name'=>$quest['name'],'reward'=>$quest['reward'],'uuid'=>$npc];
      }
      if($quest['Qtype'] == 1){
         $item = Item::jsonDeserialize($quest['reward']);
         $it = Item::jsonDeserialize($quest['item']);

      $a = "아이템 모으기\n{$it->getName()} {$it->getCount()} 개 모으기\n\n보상: {$item->getName()} {$item->getCount()} 개";
      $encode = json_encode([
      "type" => "form",
      "title" => $quest['name'],
      "content" =>
      $a,
      "buttons" => [
      [
      "text" => "수락",
      ],
      [
      "text" => "거절",
      ]
      ]
      ]);
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17339;
      $pack->formData = $encode;
      $player->dataPacket($pack);
      $this->mm[$player->getName()] = ['name'=>$quest['name'],'reward'=>$quest['reward'],'uuid'=>$npc];
      }
         
     }

     function QuestCreate(Player $player){
       
       $list2 = ["몬스터 잡기","아이템 모아오기"];
       
      $encode = json_encode(["type" => "custom_form","title" => $this->p,"content" => [["type" => "input","text" => "§4* §b지금 손에 들고있는 아이템이 보상으로 설정 됩니다 §4*§f\n\n생성할 퀘스트의 이름을 입력해주세요"],["type" => "dropdown","text" => "생성할 퀘스트의 타입을 선택 해주세요",	"options" => $list2]]]);
      
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17335;
      $pack->formData = $encode;
      $player->dataPacket($pack);
 
   }
   function QuestCreateItem(Player $player){

      $encode = json_encode(["type" => "custom_form","title" => $this->p,"content" => [["type" => "input","text" => "§4* §b지금손에 들고 있는 아이템이 보상으로 설정 됩니다 §4*§f\n\n모아와야할 아이템의 개수를 적어주세요"]]]);
      
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17337;
      $pack->formData = $encode;
      $player->dataPacket($pack);
 
   }
   function QuestCreateMonster(Player $player){
       
       $list =["닭(10)","소(11)","돼지(12)","양(13)","늑대(14)","주민(15)","버섯소(16)","오징어(17)","토끼(18)","박쥐(19)","철골램(20)","눈사람(21)","오셀롯(22)","말(23)","나귀(24)","노새(25)","스켈레톤 말(26)","좀비 말(27)","북극곰(28)","라마(29)","앵무새(30)","돌고래(31)","좀비(32)","크리퍼(33)","스켈레톤(34)","거미(35)","좀비 피그맨(36)","슬라임(37)","엔더맨(38)","좀벌레(39)","동굴 거미(40)","가스트(41)","마그마 큐브(42)","블레이즈(43)","좀비 주민(44)","마녀(45)","스트레이(46)","허스크(47)","위더 스켈레톤(48)","가디언(49)","엘더 가디언(50)","NPC(51)","위더(52)","엔더 드레곤(53)","셜커(54)"];

      $encode = json_encode(["type" => "custom_form","title" => $this->p,"content" => [["type" => "input","text" => "잡아야할 몬스터의 마리수를 적어주세요"],["type" => "dropdown","text" => "잡아야할 몬스터의 이름을 선택 해주세요",	"options" => $list]]]);
      
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17336;
      $pack->formData = $encode;
      $player->dataPacket($pack);
 
   }
   
   function QuestNpcCreate(Player $player){
       
      $encode = json_encode(["type"=>"custom_form","title"=>$this->p,"content"=>[["type"=>"input","text" => "퀘스트 엔피시의 이름을 입력해주세요"],["type"=>"input","text"=>"더이상 클리어할 퀘스트가 없을시 엔피시가 할 말을 적어주세요"]]]);
      
      $pack = new ModalFormRequestPacket();
      $pack->formId = 17343;
      $pack->formData = $encode;
      $player->dataPacket($pack);
 
   }
   
      function hell(DataPacketReceiveEvent $event){
		$pack = $event->getPacket();
		$player = $event->getPlayer();
		$nn = $player->getName();
	if($pack instanceof ModalFormResponsePacket and $pack->formId == 17335){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val[0] == null){ 
	    $player->sendMessage($this->p."퀘스트 이름을 적어주세요"); 
	return true;
	    
	}
	
	$this->create[$nn] = ['name'=>$val[0],'type'=>$val[1]];
	 if($val[1] == 0){
	self::QuestCreateMonster($player);
	 }
	 if($val[1] == 1){
	self::QuestCreateItem($player);
	 }

}
if($pack instanceof ModalFormResponsePacket and $pack->formId == 17338){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val == 0){
	    
	    $this->pl['Monster'][$nn] = ['cou' => $this->mm[$nn]['cou'],'id'=>$this->mm[$nn]['id'],'count'=>0,'name'=>$this->mm[$nn]['name'],'reward'=>$this->mm[$nn]['reward'],'uuid'=>$this->mm[$nn]['uuid']];
	    
	    unset($this->mm[$nn]);
	    $player->sendMessage($this->p."퀘스트를 수락 했습니다");
	    
	}
	
}
if($pack instanceof ModalFormResponsePacket and $pack->formId == 17339){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val == 0){
	    
	    $this->pl['Item'][$nn] = ['name'=>$this->mm[$nn]['name'],'reward'=>$this->mm[$nn]['reward'],'uuid'=>$this->mm[$nn]['uuid']];
	    
	    unset($this->mm[$nn]);
	    $player->sendMessage($this->p."퀘스트를 수락 했습니다");
	    
	}
	
}
if($pack instanceof ModalFormResponsePacket and $pack->formId == 17340){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val == 0){
	    
	 $player->sendMessage($this->pl['Monster'][$nn]['name']." 퀘스트를 포기 했습니다");
	unset($this->pl['Monster'][$nn]);
	    
	}
	
}
if($pack instanceof ModalFormResponsePacket and $pack->formId == 17341){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val == 0){
	    
	 $player->sendMessage($this->pl['Item'][$nn]['name']." 퀘스트를 포기 했습니다");
	unset($this->pl['Item'][$nn]);
	    
	}
	
}
if($pack instanceof ModalFormResponsePacket and $pack->formId == 17342){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val == 0){
	    
	 $player->sendMessage($this->pl['Item'][$nn]['name']." 퀘스트를 클리어 했습니다");
	 $player->getInventory()->addItem(Item::jsonDeserialize($this->pl['Item'][$nn]['reward']));
if(isset($this->pl[$nn][$this->pl['Item'][$nn]['uuid']])){
	 $player->getInventory()->removeItem(Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$nn]['uuid']][$this->pl[$nn][$this->pl['Item'][$nn]['uuid']]]['item']));
	 
                $this->pl[$nn][$this->pl['Item'][$nn]['uuid']]++;
                } else {
                    $player->getInventory()->removeItem(Item::jsonDeserialize($this->db['Quest'][$this->pl['Item'][$nn]['uuid']][0]['item']));

                    $this->pl[$nn][$this->pl['Item'][$nn]['uuid']] = 1;
                }
	unset($this->pl['Item'][$nn]);
	    
	}
	
}
if($pack instanceof ModalFormResponsePacket and $pack->formId == 17336){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val[0] == null){ 
	    $player->sendMessage($this->p."몬스터의 마리수를 적어주세요"); 
	return true;
	}
	$this->Monster['Quest'][$nn] = [
	    
	    "Id" => $val[1]+10,
	    'count' => $val[0],
	    'name' => $this->create[$nn]['name'],
	    'reward' => $player->getInventory()->getItemInHand()->jsonSerialize(),
	    'Qtype' => $this->create[$nn]['type']
	    
	    ];
	    unset($this->create[$nn]);
	    
	    $player->sendMessage($this->p."생성할 엔피시를 터치 해주세요");
	
	}
	if($pack instanceof ModalFormResponsePacket and $pack->formId == 17337){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val[0] == null){ 
	    $player->sendMessage($this->p."모아와야 할 아이템의 개수를 적어주세요"); 
	return true;
	}
	$this->Item['Quest'][$nn] = [
	    
	    'count' => $val[0],
	    'name' => $this->create[$nn]['name'],
	    'reward' => $player->getInventory()->getItemInHand()->jsonSerialize(),
	    'Qtype' => $this->create[$nn]['type']
	    
	    ];
	    unset($this->create[$nn]);
	    
	    $player->sendMessage($this->p."생성할 엔피시를 모아와야 할 아이템을 들고 터치 해주세요");
	
	}
		
     if($pack instanceof ModalFormResponsePacket and $pack->formId == 17343){ 
         
			$val = json_decode($pack->formData, true);
	if(is_null($val)) return true;
	
	if($val[0] == null){ 
	    $player->sendMessage($this->p."퀘스트 엔피시의 이름을 적어주세요"); 
	return true;
	    
	}
	if($val[1] == null){ 
	    $player->sendMessage($this->p."더이상 클리어할 퀘스트가 없을때 npc가 할 말을 적어주세요"); 
	return true;
	    
	}
	
	$nbt = Entity::createBaseNBT($player->asVector3(), null, $player->yaw, $player->pitch); 

$nbt->setString("UUID", UUID::fromRandom()->toString()); 

$nbt->setTag(new CompoundTag("Skin", [ new StringTag("Name", $player->getSkin()->getSkinId()), new StringTag("Data", $player->getSkin()->getSkinData()) ]));

$nbt->setString("NameTag", $val[0]);
$nbt->setString("message", $val[1]);


$entity = Entity::createEntity('YQuestEntity', $player->getLevel(), $nbt);

	$entity->setMaxHealth(50);
	$entity->setHealth(50);

        $entity->spawnToAll(); 
        

	}
}



}