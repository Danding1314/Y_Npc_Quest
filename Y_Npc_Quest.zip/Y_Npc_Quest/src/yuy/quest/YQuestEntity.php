<?php

namespace yuy\quest;

use pocketmine\entity\Human;
use pocketmine\entity\Entity;
use pocketmine\level\Level; 
use pocketmine\nbt\tag\StringTag; 
use pocketmine\nbt\tag\CompoundTag; 

class YQuestEntity extends Human{
    
    public $Message;
    public $Uuid;
    
    public function __construct(Level $level, CompoundTag $nbt) { 
        
        parent::__construct($level, $nbt); } 
        protected function initEntity(): void { 
            parent::initEntity(); 
            
            $nbt = $this->namedtag; 
        
                $this->Message = $nbt->getString("message"); 

        $this->Uuid = $nbt->getString("UUID"); 
        
}
    
    public function getMessage(){
        
        return $this->Message; 
        
    } 
    public function getUUID(): string { 
        return $this->Uuid; 
        
    }
}